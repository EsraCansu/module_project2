#include <iostream>
#include <cmath>

using namespace std;

class Circuit {
private:
    double R, C;

public:
    void intro(double resistance, double capacitance) {
        R = resistance;
        C = capacitance;
    }

    double calculation_of_Vout(double Vin, double f) {
        double Vout;
        Vout = (-1 / (R * C)) * Vin * (1 / f);
        return Vout;
    }

    double calculation_of_Gain(double Vin, double Vout) {
        double gain;
        gain = Vout / Vin;
        return gain;
    }
};

int main() {
    double R, C;
    double Vin, f;

    cout << "Please enter your resistance value (ohm): ";
    cin >> R;
    cout << "Please enter your capacitance value (Farad): ";
    cin >> C;

    // Create an instance of Circuit
    Circuit circuit;
    circuit.intro(R, C);

    bool exit = false;
    while (!exit) {
        cout << "\nMenu:\n";
        cout << "1. Enter Vin and f\n";
        cout << "2. Change R and C\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        int choice;
        cin >> choice;

        switch (choice) {
            case 1: {
                cout << "Enter Vin (type of V): ";
                cin >> Vin;
                cout << "Enter f (frequency in seconds): ";
                cin >> f;

                double Vout = circuit.calculation_of_Vout(Vin, f);
                double gain = circuit.calculation_of_Gain(Vin, Vout);

                cout << "Vout = " << Vout << " V" << endl;
                cout << "Gain = " << gain << endl;
                break;
            }
            case 2: {
                cout << "Enter new resistance value (ohm): ";
                cin >> R;
                cout << "Enter new capacitance value (Farad): ";
                cin >> C;
                circuit.intro(R, C);
                cout << "Resistance and capacitance updated." << endl;
                break;
            }
            case 3: {
                exit = true;
                cout << "Exiting..." << endl;
                break;
            }
            default: {
                cout << "Invalid choice. Please try again." << endl;
                break;
            }
        }
    }

    return 0;
}